<script>
import axios from 'axios'
import Loading from '../chat/components/Loading.vue'
import serviceHost from '../helper'
export default {
  components: {
    Loading,
  },
  data() {
    return {
      setPassword: '',
      account: '',
      password: '',
      level: '0',
      showLoading: false,
      modifyLevel: '0',
      modifyPassword: '',
      chcekLevel: false,
      chcekPassword: false,
      modifyAccount: '',
      msg: '',
    }
  },
  methods: {
    chooseLevel(val) {
      this.level = val
    },
    chooseModifyLevel(val) {
      this.modifyLevel = val
    },
    async fetchCreate() {
      this.showLoading = true
      const form = this.password
        ? {
            level: Number(this.level),
            password: this.password,
          }
        : { level: Number(this.level) }
      const url = `${serviceHost}/api/create_client`
      const res = await axios.post(url, form)
      if (res.data.err === 0) {
        this.account = res.data.result.account || ''
        this.password = res.data.result.password || ''
      }
      this.showLoading = false
    },
    async fetchModify() {
      this.showLoading = true
      const form = {
        account: this.modifyAccount,
        password: this.chcekPassword ? this.modifyPassword : '',
        level: this.chcekLevel ? this.modifyLevel : '',
      }
      const url = `${serviceHost}/api/modify`
      const res = await axios.post(url, form)
      if (res.data.err === 0)
        this.msg = '修改成功'

      else
        this.msg = '修改失败'

      this.showLoading = false
    },
  },
}
</script>

<template>
  <div class="manager">
    <Loading v-if="showLoading" />
    <div>
      创建账号
      <div>
        <input type="radio" name="level" value="0" :checked="level === '0'" @click="chooseModifyLevel('0')"><label for="0" name="level">3个设备同时在线</label>
        <input type="radio" name="level" value="1" :checked="level === '1'" @click="chooseModifyLevel('1')"><label for="1" name="level">5个设备同时在线</label>
      </div>
      <div>密码（可不填，不填随机生成16位密码）<div><input v-model="setPassword"></div></div>
      <button @click="fetchCreate">
        创建账号
      </button>
      <div>
        生成的账号:<div><input v-model="account" readonly></div>
      </div>
      <div>
        生成的密码:<div><input v-model="password" readonly></div>
      </div>
    </div>
    ____________________________________________________
    <div>
      修改账号信息
      <div>修改的账号<div><input v-model="modifyAccount"></div></div>
      <div>
        <input type="checkbox" :checked="chcekLevel" @change="chcekLevel = !chcekLevel">
        <input type="radio" name="level" value="0" :checked="modifyLevel === '0'" @click="chooseLevel('0')"><label for="0" name="level">3个设备同时在线</label>
        <input type="radio" name="level" value="1" :checked="modifyLevel === '1'" @click="chooseLevel('1')"><label for="1" name="level">5个设备同时在线</label>
      </div>
      <div><input type="checkbox" :checked="chcekPassword" @change="chcekPassword = !chcekPassword">修改密码<div><input v-model="modifyPassword"></div></div>
      <button @click="fetchModify">
        确认修改
      </button>
      <div>
        {{ msg }}
      </div>
    </div>
  </div>
</template>

<style scoped>
input{
  height: 44px;
  font-size: 16px;
  background-color: #F4F5F6;
  border-radius: 5px;
  border: 1px solid #cccccc;
  margin: 0 5px;
}
.manager{
  padding: 10px 20px;
}
button{
  background-color: #007aff;
  color:#ffffff;
  font-size: 16px;
  padding: 5px 10px;
  border-radius: 5px;
  margin: 10px;
}
button:active{
  opacity: 0.7;
}
</style>
