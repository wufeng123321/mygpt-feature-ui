import ChatLayout from './Layout.vue'

export { ChatLayout }
