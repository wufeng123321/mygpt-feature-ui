const serviceHost = 'http://localhost:8000' // 自己的登录服务域名
export default serviceHost
