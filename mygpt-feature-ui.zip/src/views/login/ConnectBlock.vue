<script>
export default {

}
</script>

<template>
  <div class="connect-block" @click.self="$emit('click')">
    <img src="../../assets/connect.jpg" class="content" @click.stop="">
  </div>
</template>

<style scoped>
.connect-block{
  height: 100vh;
  width: 100vw;
  background-color: rgba(0, 0, 0, 0.3);
  position: absolute;
  top: 0;
  left: 0;
  z-index: 999;
}
.connect-block .content{
  position: absolute;
  top: 40%;
  left: 50%;
  transform: translate(-50%,-50%);
  width: 20rem;
}
</style>
