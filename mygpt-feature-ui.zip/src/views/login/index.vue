<script>
import { NButton, NCheckbox, NInput, NSpace, useDialog } from 'naive-ui'
import axios from 'axios'
import md5 from 'md5'
import serviceHost from '../helper'
import Loading from '../chat/components/Loading.vue'
import ConnectBlock from './ConnectBlock.vue'
export default {
  components: {
    NInput,
    NSpace,
    NCheckbox,
    NButton,
    ConnectBlock,
    Loading,
  },
  data() {
    return {
      account: '', // 账号
      password: '', // 密码
      show: false,
      remember: false, // 是否记住密码
      deviceSn: '', // 设备号
      dialog: useDialog(),
      showLoading: false,
    }
  },
  mounted() {
    const remember = localStorage.getItem('GPT_REMEMBER')
    if (Number(remember) === 1) {
      this.remember = true
      const account = localStorage.getItem('GPT_ACCOUNT')
      const password = localStorage.getItem('GPT_PASSWORD')
      this.account = account || this.account
      this.password = password || this.password
    }
    else { this.remember = false }
    const deviceSn = localStorage.getItem('GPT_DEVINCE_SN')
    this.deviceSn = deviceSn || this.deviceSn
  },
  methods: {
    async fetchLogin(deviceSn) {
      // 调用登录接口
      this.showLoading = true
      const form = {
        account: this.account,
        password: this.password,
        device_sn: deviceSn,
      }
      const url = `${serviceHost}/api/login`
      const res = await axios.post(url, form)
      this.showLoading = false
      return res
    },
    async handleSubmit() {
      // 登录事件
      const timestamp = (Date.parse(new Date())) / 1000
      const deviceSn = this.deviceSn !== '' ? this.deviceSn : md5(`${this.account}_${timestamp}`)
      const res = await this.fetchLogin(deviceSn)
      if (res.data.err === 0) {
        if (this.remember) {
          localStorage.setItem('GPT_ACCOUNT', this.account)
          localStorage.setItem('GPT_PASSWORD', this.password)
          localStorage.setItem('GPT_REMEMBER', this.remember ? 1 : 0)
        }
        localStorage.setItem('GPT_DEVINCE_SN', deviceSn)
        localStorage.setItem('GPT_LOGINED', '1')
        localStorage.setItem('GPT_HAVE_VERIFY', '1')
        this.$router.push('/')
      }
      else {
        this.dialog.error({
          title: '登录失败',
          content: res.data.msg || '',
          positiveText: '确定',
        })
      }
    },
    handleConnect() {
      // 弹出联系框
      this.show = true
    },
    handleChangeRemember() {
      // 修改记住密码
      this.remember = !this.remember
    },
  },
}
</script>

<template>
  <div class="login">
    <div class="title">
      欢迎登录系统
    </div>
    <div class="dividing-line" />
    <form class="login-form">
      <NSpace vertical>
        <NInput v-model:value="account" placeholder="请输入登录账号" class="text-input">
          <template #prefix>
            <img src="../../assets/user.png" class="icon">
          </template>
        </NInput>
        <NInput v-model:value="password" placeholder="请输入登录密码" type="password" class="text-input">
          <template #prefix>
            <img src="../../assets/lock.png" class="icon">
          </template>
        </NInput>
        <NCheckbox :checked="remember" style="--n-color-checked:#3498DB;--n-border-focus:1px solid #3498DB;--n-border-checked:1px solid #3498DB;" @change="handleChangeRemember">
          <div class="remenber">
            记住密码
          </div>
        </NCheckbox>
        <NButton type="info" class="login-btn" @click="handleSubmit">
          登录
        </NButton>
      </NSpace>
    </form>
    <div class="connect">
      如果需要账号可以<div class="connect-link" @click="handleConnect">
        联系管理员
      </div>
    </div>
    <ConnectBlock v-show="show" @click="show = false" />
    <Loading v-if="showLoading" />
  </div>
</template>

<style scoped>
.login{
  height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding-top: 30%;
}
.login .title{
  font-size: 1.5rem;
  color: #191d21;
  font-weight: 500;
}
.dividing-line{
  margin-top: 1rem;
  height: 5px;
  width: 3rem;
  background-color: #3498DB;
}
form{
  width: 20rem;
  margin-top: 1rem;
}
.login-btn{
  width: 100%;
  font-size: 1rem;
  height: 3.2rem !important;
}
form div{
  margin-bottom: 0.8rem;
}
.remenber{
  color: #888888;
}
.text-input{
  height: 3.2rem;
  line-height: 3.2rem;
  font-size: 1rem;
}
.icon{
  width: 1rem;
  margin-right: 0.5rem;
}
.connect{
  color: #333333;
  font-size: 0.8rem;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 0.2rem;
}
.connect-link{
  color: #3498DB;
  text-decoration: underline;
  text-underline-offset: 0.2rem;
  cursor: pointer;
}
.connect-link:hover{
  opacity: 0.7;
}
</style>
